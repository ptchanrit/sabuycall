"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./img/banner-1.png":
/*!**************************!*\
  !*** ./img/banner-1.png ***!
  \**************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval(__webpack_require__.ts("__webpack_require__.r(__webpack_exports__);\n/* harmony default export */ __webpack_exports__[\"default\"] = ({\"src\":\"/_next/static/media/banner-1.fca3a715.png\",\"height\":900,\"width\":2160,\"blurDataURL\":\"/_next/image?url=%2F_next%2Fstatic%2Fmedia%2Fbanner-1.fca3a715.png&w=8&q=70\",\"blurWidth\":8,\"blurHeight\":3});//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9pbWcvYmFubmVyLTEucG5nLmpzIiwibWFwcGluZ3MiOiI7QUFBQSwrREFBZSxDQUFDLHFNQUFxTSIsInNvdXJjZXMiOlsid2VicGFjazovL19OX0UvLi9pbWcvYmFubmVyLTEucG5nP2YwNGUiXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGRlZmF1bHQge1wic3JjXCI6XCIvX25leHQvc3RhdGljL21lZGlhL2Jhbm5lci0xLmZjYTNhNzE1LnBuZ1wiLFwiaGVpZ2h0XCI6OTAwLFwid2lkdGhcIjoyMTYwLFwiYmx1ckRhdGFVUkxcIjpcIi9fbmV4dC9pbWFnZT91cmw9JTJGX25leHQlMkZzdGF0aWMlMkZtZWRpYSUyRmJhbm5lci0xLmZjYTNhNzE1LnBuZyZ3PTgmcT03MFwiLFwiYmx1cldpZHRoXCI6OCxcImJsdXJIZWlnaHRcIjozfTsiXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./img/banner-1.png\n"));

/***/ })

});