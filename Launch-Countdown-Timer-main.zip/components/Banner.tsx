import React from 'react'
import Image from 'next/image'
import Banner1 from '../img/banner-1.png'

export const Banner = {
    return(
     <>
    <Image src={Banner1} layout='resposive' />
    </>
    )
}